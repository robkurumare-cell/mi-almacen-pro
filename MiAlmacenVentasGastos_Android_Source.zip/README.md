# Mi Almacén — Ventas y Gastos (Android)

Proyecto Android nativo mínimo (WebView local) con registro de ventas y gastos, resumen, historial y exportación CSV. Los datos se guardan localmente en el teléfono usando localStorage.

## Cómo generar el APK
1. Instala Android Studio en un computador.
2. Abre la carpeta `MiAlmacenVentasGastos` en Android Studio.
3. Espera la sincronización de Gradle.
4. Usa **Build > Build APK(s)**.
5. El APK de prueba aparecerá normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

## Importante
- Este proyecto fuente no es un APK ya compilado.
- Guarda datos en un solo teléfono; no sincroniza entre empleados.
- No incluye usuarios, nube, integración con FullPyme ni cálculo tributario.
- Antes de usarlo con información real, prueba respaldos y registros.
